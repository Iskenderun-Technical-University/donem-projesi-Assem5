﻿namespace Book_Control
{
    partial class DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoard));
            label4 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            label8 = new Label();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            label7 = new Label();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            label6 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            panel6 = new Panel();
            UsersLbl = new Label();
            pictureBox6 = new PictureBox();
            label2 = new Label();
            panel7 = new Panel();
            label3 = new Label();
            pictureBox7 = new PictureBox();
            BookStockLbl = new Label();
            panel8 = new Panel();
            AmountLbl = new Label();
            pictureBox8 = new PictureBox();
            label9 = new Label();
            panel1.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(64, 64, 64);
            label4.Location = new Point(876, -3);
            label4.Name = "label4";
            label4.Size = new Size(25, 30);
            label4.TabIndex = 26;
            label4.Text = "X";
            label4.Click += label4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Liberation Sans", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(428, 5);
            label1.Name = "label1";
            label1.Size = new Size(171, 23);
            label1.TabIndex = 25;
            label1.Text = "IT BOOK STORE";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(64, 64, 64);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(171, 538);
            panel1.TabIndex = 24;
            // 
            // panel5
            // 
            panel5.Controls.Add(pictureBox5);
            panel5.Controls.Add(label8);
            panel5.Location = new Point(0, 239);
            panel5.Name = "panel5";
            panel5.Size = new Size(168, 33);
            panel5.TabIndex = 3;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(3, 1);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(35, 30);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 18;
            pictureBox5.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(40, 4);
            label8.Name = "label8";
            label8.Size = new Size(71, 25);
            label8.TabIndex = 18;
            label8.Text = "Logout";
            label8.Click += label8_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(label7);
            panel4.Location = new Point(0, 184);
            panel4.Name = "panel4";
            panel4.Size = new Size(168, 33);
            panel4.TabIndex = 2;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 1);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(35, 30);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 18;
            pictureBox4.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(40, 4);
            label7.Name = "label7";
            label7.Size = new Size(104, 25);
            label7.TabIndex = 18;
            label7.Text = "DashBoard";
            label7.Click += label7_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(label6);
            panel3.Location = new Point(0, 130);
            panel3.Name = "panel3";
            panel3.Size = new Size(168, 33);
            panel3.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(35, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 18;
            pictureBox3.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(40, 4);
            label6.Name = "label6";
            label6.Size = new Size(58, 25);
            label6.TabIndex = 18;
            label6.Text = "Users";
            label6.Click += label6_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(label5);
            panel2.Location = new Point(0, 78);
            panel2.Name = "panel2";
            panel2.Size = new Size(168, 33);
            panel2.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 1);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(35, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(40, 4);
            label5.Name = "label5";
            label5.Size = new Size(62, 25);
            label5.TabIndex = 18;
            label5.Text = "Books";
            label5.Click += label5_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(72, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(64, 64, 64);
            panel6.Controls.Add(UsersLbl);
            panel6.Controls.Add(pictureBox6);
            panel6.Controls.Add(label2);
            panel6.Location = new Point(276, 413);
            panel6.Name = "panel6";
            panel6.Size = new Size(490, 53);
            panel6.TabIndex = 27;
            // 
            // UsersLbl
            // 
            UsersLbl.AutoSize = true;
            UsersLbl.BackColor = Color.Transparent;
            UsersLbl.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            UsersLbl.ForeColor = Color.White;
            UsersLbl.Location = new Point(152, 0);
            UsersLbl.Name = "UsersLbl";
            UsersLbl.Size = new Size(70, 52);
            UsersLbl.TabIndex = 19;
            UsersLbl.Text = " Stock";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(0, 1);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(38, 52);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 18;
            pictureBox6.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(33, -10);
            label2.Name = "label2";
            label2.Size = new Size(63, 52);
            label2.TabIndex = 18;
            label2.Text = "Users";
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(64, 64, 64);
            panel7.Controls.Add(label3);
            panel7.Controls.Add(pictureBox7);
            panel7.Controls.Add(BookStockLbl);
            panel7.Location = new Point(276, 350);
            panel7.Name = "panel7";
            panel7.Size = new Size(490, 53);
            panel7.TabIndex = 28;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(33, 0);
            label3.Name = "label3";
            label3.Size = new Size(116, 52);
            label3.TabIndex = 19;
            label3.Text = "Books Stock";
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(0, 1);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(38, 52);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 18;
            pictureBox7.TabStop = false;
            // 
            // BookStockLbl
            // 
            BookStockLbl.AutoSize = true;
            BookStockLbl.BackColor = Color.Transparent;
            BookStockLbl.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            BookStockLbl.ForeColor = Color.White;
            BookStockLbl.Location = new Point(152, 1);
            BookStockLbl.Name = "BookStockLbl";
            BookStockLbl.Size = new Size(70, 52);
            BookStockLbl.TabIndex = 18;
            BookStockLbl.Text = " Stock";
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(64, 64, 64);
            panel8.Controls.Add(AmountLbl);
            panel8.Controls.Add(pictureBox8);
            panel8.Controls.Add(label9);
            panel8.Location = new Point(276, 282);
            panel8.Name = "panel8";
            panel8.Size = new Size(490, 53);
            panel8.TabIndex = 29;
            // 
            // AmountLbl
            // 
            AmountLbl.AutoSize = true;
            AmountLbl.BackColor = Color.Transparent;
            AmountLbl.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            AmountLbl.ForeColor = Color.White;
            AmountLbl.Location = new Point(152, 0);
            AmountLbl.Name = "AmountLbl";
            AmountLbl.Size = new Size(70, 52);
            AmountLbl.TabIndex = 19;
            AmountLbl.Text = " Stock";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(-8, 0);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(46, 53);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 18;
            pictureBox8.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Amiri", 14.2499981F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(33, -10);
            label9.Name = "label9";
            label9.Size = new Size(128, 52);
            label9.TabIndex = 18;
            label9.Text = "Total Amount";
            // 
            // DashBoard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(899, 538);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(label4);
            Controls.Add(label1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "DashBoard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DashBoard";
            Load += DashBoard_Load;
            panel1.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private Label label1;
        private Panel panel1;
        private Panel panel5;
        private PictureBox pictureBox5;
        private Label label8;
        private Panel panel4;
        private PictureBox pictureBox4;
        private Label label7;
        private Panel panel3;
        private PictureBox pictureBox3;
        private Label label6;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Label label5;
        private PictureBox pictureBox1;
        private Panel panel6;
        private PictureBox pictureBox6;
        private Label label2;
        private Panel panel7;
        private PictureBox pictureBox7;
        private Label BookStockLbl;
        private Panel panel8;
        private PictureBox pictureBox8;
        private Label label9;
        private Label label3;
        private Label UsersLbl;
        private Label AmountLbl;
    }
}